#reads the file and converts it to uppercase
f = open ("hijk.txt", "r")
a = (f.read().upper())
f.close()

#creates a new file and pastes uppercase version of the file above 
f = open("demofile3.txt", "a")
f.write(a)
f.close()

